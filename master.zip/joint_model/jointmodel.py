import numpy as np
import os
import scipy.io as sio

from parpre_step import *
from phaselink_MLE4 import *
from prepare_seg_par import *
from segment_est_point_ph_by_triplet_closure_par_aid.segment_est_point_ph_by_triplet_closure_par_aid import *



# sample input
# Output=jointmodel(obs,shortbaseline,80000,9.6000000e+09,667425.0045,760,640,20.1048,11.18145476827794302475,11.313365,300,300,700,4)


# def jointmodel(obs,sb,num,frequency,slantran,width,lines,incangle,spa_r,spa_azi,interval_r,interval_azi,radius):
#     '''
#
#     :param obs:
#     :param sb:
#     :param num:
#     :param frequency:
#     :param slantran:
#     :param width:
#     :param lines:
#     :param incangle:
#     :param spa_r:
#     :param spa_azi:
#     :param interval_r:
#     :param interval_azi:
#     :param radius:
#     :return:
#     '''

### test input ###
import pandas as pd
obs = sio.loadmat('obs.mat')['obs']
sb = np.array(pd.read_csv('shortbaseline', delimiter='\s+',
                        names=['SCE1', 'SCE2', 'Bp', 'Bt']))

num,frequency,slantran,width,lines,incangle,spa_r,spa_azi,interval_r,interval_azi,radius = \
    80000,9.6000000e+09,667425.0045,760,640,20.1048,11.18145476827794302475,11.313365,300,300,700
###



c = 299792458
wavelen = c / frequency
ref_point = 1
ref_slc = 1

if not os.path.isfile('Input.mat'):
    Input = parpre_step(obs, sb, num, wavelen, slantran, incangle, spa_r, spa_azi, width, lines, interval_r,
                        interval_azi, radius, ref_point, ref_slc)
else:
    Input = sio.loadmat('Input.mat')['Input']
coh = sio.loadmat('coh.mat')['coh']

est_SMph, est_gamma, est_obs = phaselink_MLE4(obs, coh, Input)

sio.savemat('est_SMph.mat', est_SMph)
sio.savemat('est_gamma.mat', est_gamma)
sio.savemat('est_obs.mat', est_obs)
del est_SMph, est_gamma, est_obs


T = 0.7
idx = est_gamma[:, -1] >= T
obs_new = est_obs[idx,:]
del est_obs, est_gamma

seg_par = prepare_seg_par(obs_new, 10000, 10000)
point_ph = segment_est_point_ph_by_triplet_closure_par_aid(obs_new, Input, seg_par, 1) #TODO: check last index input is 1-base
sio.savemat("point_ph.mat", point_ph)
# defo_rate, defo, dem_error = point_ph2par(point_ph, Input)




    #
    # #TODO: implement various test cases that are commented out
    #
    #
    # Output = 1
    # print('All finish!')
    # return Output
