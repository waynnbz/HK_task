import numpy as np
from multiprocessing import Pool


def mod(a, b):
    c = a // b
    r = a - c * b
    return r


def lscov(A, B, V):
    '''
    Computing General Least Squares
    参考 https://ggf.readthedocs.io/en/stable/_modules/ggf/matlab_funcs.html
    '''
    W = np.sqrt(np.linalg.inv(V))
    Aw = np.dot(W, A)
    Bw = np.dot(B.T, W)

    # set rcond=1e-10 to prevent diverging odd indices in x
    x, residuals, rank, s = np.linalg.lstsq(Aw, Bw.T, rcond=1e-10)

    return x


def for_loop_func(i, y1_temp, NSLC, B, allEST_init_blk, allRES_blk):
    y = y1_temp[:, i]
    # TODO: robust_fit_md函数尚未完成
    # xhat, stats = robust_fit_md(np.hstack((np.ones((NSLC - 1, 1)), B)), y)
    # allEST_init_blk[:, i] = xhat[1]
    # allRES_blk[:, i] = stats["resid"]
    pass


def di2deforate(samp_di, input, method_flag=1):
    """
    @param samp_di:
    @param input:
    @param method_flag: 0: total defo / total time
                        1: perform regression by ordinary least square (default)
                        2: perform robustfit
                        3: lscov
    """
    NTCP = samp_di.shape[0]
    interval = input["interval"]
    NSLC = len(interval) + 1
    T_year = np.abs(interval) / 365
    B = T_year
    B = np.cumsum(B, axis=0)
    PROJ_LS = np.linalg.pinv(B.T @ B) * B.T
    di = samp_di[:, 4:]
    dis = np.hstack((np.zeros((NTCP, 1)), di))
    cum_dis = np.cumsum(dis, axis=1)
    defo = np.hstack((samp_di[:, :4], cum_dis))
    y1 = cum_dis.conj().T
    y1 = y1[1:, :]
    if method_flag == 0:
        y1_end = y1[-1].reshape(-1, 1)
        B_end = B[-1]
        allEST_init = y1_end / B_end[0]
        allRES = np.zeros((NSLC - 1, NTCP))
    elif method_flag == 1:
        allEST_init = np.zeros((1, NTCP))
        allRES = np.zeros((NSLC - 1, NTCP))
        for i in range(NTCP):
            if mod(i, 1000000) == 0 and i > 1:
                print("LS solver:: currently at patch " + str(i) + ' of ' + str(NTCP))
            y = y1[:, i]
            xhat = PROJ_LS @ y
            yhat = B @ xhat
            ehat = y - yhat
            allRES[:, i] = ehat
            allEST_init[0, i] = xhat
    elif method_flag == 2:
        blockstep = 10000
        blocknum = np.ceil(NTCP / blockstep)
        allEST_init_cell = np.zeros((1, blocknum))
        allRES_cell = np.zeros((1, blocknum))
        pool = Pool(processes=2)
        for j in range(blocknum):
            print("Process block number" + str(j) + "of" + str(blocknum))
            pt_sidx = j * blockstep + 1
            pt_eidx = np.min(j * blockstep, NTCP)
            pt_idx = np.arange(pt_sidx, pt_eidx + 1).reshape(-1, 1)
            nps_blk = len(pt_idx)
            y1_temp = y1[:, pt_idx]
            allEST_init_blk = np.zeros((1, nps_blk))
            allRES_blk = np.zeros((NSLC - 1, nps_blk))
            for i in range(nps_blk):
                pool.apply(for_loop_func, args=(i, y1_temp, NSLC, B, allEST_init_blk, allRES_blk))
            pool.close()
            pool.join()
            allEST_init_cell[0, j] = allEST_init_blk
            allRES_cell[0, j] = allRES_blk
    elif method_flag == 3:
        y_var = np.var(y1, axis=1).reshape(-1, 1)
        XHAT = lscov(np.hstack((np.ones((NSLC - 1, 1)), B)), y1, np.diag(y_var.squeeze()))
        allRES = np.hstack((np.ones((NSLC - 1, 1)), B)) @ XHAT - y1
        allEST_init = XHAT[1, :]
    else:
        raise Exception('Wrong method flag')
    allRES = allRES.T
    allEST_init = allEST_init.T.reshape(-1, 1)
    deforate = np.hstack((samp_di[:, 0:4], allEST_init))
    residual = np.hstack((samp_di[:, 0:4], allRES))
    return defo, deforate, residual
