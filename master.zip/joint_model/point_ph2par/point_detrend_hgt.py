import numpy as np
from scipy.spatial import Delaunay
from itertools import combinations


def edges(simps):
    '''
    接受矩阵simps，其每一行为一多边形的顶点标签，返回所有的独特边的标签组合
    '''
    if simps.shape[1] > 1:
        edg = [list(combinations(s, 2)) for s in np.sort(simps)]
        edg = np.unique(np.concatenate(edg), axis=0)
    else:
        raise Exception('Insufficient vertices')
    return edg


def point_detrend_hgt(coor_ght, value, poly_order=2, network_flag=0, estimation_method=0):
    """
    @param coor_ght: vector of  (x, y)
    @param value: vector of values
    @param poly_order: the order of plane (default 2)
    @param network_flag: 0 (no network, default), 1 (Delaunay network)
    @param estimation_method: 0 (robustfit, default), 1 (lsmr and subset network detection)
    """
    X, Y, H = coor_ght[:, 0], coor_ght[:, 1], coor_ght[:, 2]
    minx, maxx, miny, maxy = np.min(X), np.max(X), np.min(Y), np.max(Y)
    a, b = 0, 1
    X = (b - a) * (X - minx) / (maxx - minx) + a
    Y = (b - a) * (X - miny) / (maxy - miny) + a
    H = H / 1000
    if network_flag == 0:
        dx = X
        dy = Y
        dxdy = dx * dy
        dx2 = dx * dx
        dy2 = dy * dy
        dx2dy = dx * dx * dy
        dxdy2 = dx * dy * dy
        dx3 = X * X * X
        dy3 = Y * Y * Y
        dh = H
        dh2 = dh * dh
        dxdh = dx * dh
        dydh = dy * dh
        dxdydh = dx * dy * dh
        dx2dh = dx2 * dh
        dy2dh = dy2 * dh
        yy = value
    elif network_flag == 1:
        X_temp = X
        Y_temp = Y
        DT = Delaunay(np.hstack((X_temp, Y_temp)))
        Arctem = edges(DT.simplices)
        Arc = np.unique(np.sort(Arctem, 1), axis=1)
        IDX_to = Arc[:, 1]
        IDX_from = Arc[:, 0]
        print("Constrcut network finished")
        dx = X[IDX_to] - X[IDX_from]
        dy = Y[IDX_to] - Y[IDX_from]
        dxdy = X[IDX_to] * Y[IDX_to] - X[IDX_from] * Y[IDX_from]
        dx2 = X[IDX_to] ** 2 - X[IDX_from] ** 2
        dy2 = Y[IDX_to] ** 2 - Y[IDX_from] ** 2
        dh = H[IDX_to] - H[IDX_from]
        dh2 = H[IDX_to] ** 2 - H[IDX_from] ** 2
        yy = value[IDX_to] - value[IDX_from]
    else:
        raise Exception("Wrong network_flag input!")
    if poly_order == 1:
        SLC_arc_poly = np.hstack((dx, dy, dxdy, dh))
    elif poly_order == 11:
        SLC_arc_poly = np.hstack((dx, dy, dxdy, dh, dh2))
    elif poly_order == 2:
        SLC_arc_poly = np.hstack((dx, dy, dxdy, dx2, dy2, dh))
    elif poly_order == 21:
        SLC_arc_poly = np.hstack((dx, dy, dxdy, dx2, dy2, dh, dh2))
    elif poly_order == 22:
        SLC_arc_poly = np.hstack((dx, dy, dxdy, dx2, dy2, dx2dh, dy2dh, dh, dh2))
    elif poly_order == 3:
        SLC_arc_poly = np.hstack((dx, dy, dxdy, dx2, dy2, dx2dy, dxdy2, dx3, dy3, dh))
    elif poly_order == 31:
        SLC_arc_poly = np.hstack((dx, dy, dxdy, dx2, dy2, dx2dy, dxdy2, dx3, dy3, dh, dh2))
    elif poly_order == 0:
        SLC_arc_poly = dh
    elif poly_order == -1:
        SLC_arc_poly = np.hstack((dh, dh2))
    elif poly_order == -11:
        SLC_arc_poly = np.hstack((dxdh, dydh, dxdydh, dh, dh2))
    elif poly_order == -12:
        SLC_arc_poly = np.hstack((dxdh, dydh, dxdydh, dx2dh, dy2dh, dh, dh2))
    else:
        raise Exception("Wrong poly_order!")
    print("Constrcut design matrix finished")
    yy = yy.flatten()
    if estimation_method == 0:
        print("Using robustfit!")
        # TODO: par=robustfit(SLC_arc_poly,yy)
        par = None
    elif estimation_method == 1:
        print("Using lsmr!")
        # TODO: lsmr
        # par = lsmr(np.hstack((np.ones(len(yy), 1), SLC_arc_poly)), yy)
    else:
        raise Exception("Wrong estimation_method!")
    if poly_order == 1:
        trend = par[0] + par[1] * X + par[2] * Y + par[3] * X * Y + par[4] * H
    elif poly_order == 11:
        trend = par[0] + par[1] * X + par[2] * Y + par[3] * X * Y + par[4] * H + par[5] * (H ** 2)
    elif poly_order == 2:
        trend = par[0] + par[1] * X + par[2] * Y + par[3] * X * Y + par[4] * (X ** 2) + par[5] * (Y ** 2) + par[6] * H
    elif poly_order == 21:
        trend = par[0] + par[1] * X + par[2] * Y + par[3] * X * Y + par[4] * (X ** 2) + par[5] * (Y ** 2) + par[6] * H \
                + par[7] * (H ** 2)
    elif poly_order == 22:
        trend = par[0] + par[1] * X + par[2] * Y + par[3] * X * Y + par[4] * (X ** 2) + par[5] * (Y ** 2) + par[6] * (
                X ** 2) * H + par[7] * (Y ** 2) * H + par[8] * H + par[9] * (H ** 2)
    elif poly_order == 3:
        trend = par[0] + par[1] * X + par[2] * Y + par[3] * X * Y + par[4] * (X ** 2) + par[5] * (Y ** 2) + par[
            6] * (X ** 2) * Y + par[7] * X * (Y ** 2) + par[8] * (X ** 3) + par[9] * (Y ** 3) + par[10] * H
    elif poly_order == 31:
        trend = par[0] + par[1] * X + par[2] * Y + par[3] * X * Y + par[4] * (X ** 2) + par[5] * (Y ** 2) + par[6] * (
                X ** 2) * Y + par[7] * X * (Y ** 2) + par[8] * (X ** 3) + par[9] * (Y ** 3) + par[10] * H + par[
                    11] * (H ** 2)
    elif poly_order == 0:
        trend = par[0] + par[1] * H
    elif poly_order == -1:
        trend = par[0] + par[1] * H + par[2] * (H ** 2)
    elif poly_order == -11:
        trend = par[0] + par[1] * X * H + par[2] * Y * H + par[3] * X * Y * H + par[4] * H + par[5] * (H ** 2)
    elif poly_order == -12:
        trend = par[0] + par[1] * X * H + par[2] * Y * H + par[3] * X * Y * H + par[4] * (X ** 2) * H + par[5] * (
                Y ** 2) * H + par[6] * H + par[7] * (H ** 2)
    else:
        raise Exception("Wrong poly_order!")
    detrend = value - trend
    return detrend, trend, par
