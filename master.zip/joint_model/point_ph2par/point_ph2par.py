import numpy as np
from sklearn.neighbors import NearestNeighbors
from di2deforate import di2deforate
from point_detrend_hgt import point_detrend_hgt


def point_ph2par(point_ph, Input, ref_lonlat=(0, 0)):
    coor = point_ph[:, 0:5]
    ph = point_ph[:, 5:]
    NPS, Nintv = ph.shape[0], ph.shape[1]
    detrend_point_ph = point_ph
    detrend_point_ph_correct, dem_error_est = correct_dem_error_by_ica(detrend_point_ph, Input)
    detrend_ph_correct = detrend_point_ph_correct[:, 5:]
    KK = (-4 * np.pi / Input["wavelen"]) * 1e-3
    di = detrend_ph_correct / KK
    di = di - np.tile(np.mean(di, axis=0), (NPS, 1))
    ref_lonlat = np.array(list(ref_lonlat))
    if np.sum(np.abs(ref_lonlat)) != 0:
        neigh = NearestNeighbors(n_neighbors=10)
        neigh.fit(coor[:, 2:4])
        pt_idx = neigh.kneighbors(ref_lonlat)
        di_ref = np.mean(di[pt_idx, :], axis=0)
        di = di - np.tile(di_ref, (NPS, 1))
    defo, defo_rate, residual = di2deforate(np.hstack((coor[:, 0: 4], di)), Input, 3)
    defo_rate = np.hstack((coor, defo_rate[:, -1]))
    defo = np.hstack((coor, defo[:, 4:]))
    dem_error = np.hstack((coor, dem_error_est))
    residual = np.hstack((coor, residual[:, 5:]))
    return defo_rate, defo, dem_error, residual


def linear_detrend(point_ph):
    ph = point_ph[:, 5:]
    coor = point_ph[:, 0:5]
    NPS, Nintv = ph.shape[0], ph.shape[1]
    detrend_ph = np.zeros((NPS, Nintv))
    for i in range(Nintv):
        detrend_ph[:, i] = point_detrend_hgt(np.hstack((coor[:, 0:2], coor[:, 4]), ph[:, i], -12, 0, 1))
    detrend_point_ph = np.hstack((coor, detrend_ph))
    return detrend_point_ph


def correct_dem_error_by_ica(detrend_point_ph, Input):
    detrend_ph = detrend_point_ph[:, 5:]
    NPS, Nintv = detrend_ph.shape[0], detrend_ph.shape[1]
    detrend_ph = detrend_ph - np.tile(detrend_ph[0, :], (NPS, 1))
    h2p_se = Input["h2p_se"]
    h2p_se_matrix = np.tile(h2p_se.conj().T, (NPS, 1))
    # TODO: ica_dem_error_single_2019
    dem_error_est = ica_dem_error_single_2019(detrend_ph.conj().T, h2p_se).conj().T
    dem_matrix = np.tile(dem_error_est, (1, Nintv))
    dem_error_phase = h2p_se_matrix * dem_matrix
    detrend_ph_correct = detrend_ph - dem_error_phase
    detrend_point_ph_correct = np.hstack((detrend_point_ph[:, 0:5], detrend_ph_correct))
    return detrend_point_ph_correct, dem_error_est
