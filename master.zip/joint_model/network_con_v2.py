# -*- coding: utf-8 -*-
"""
Created on Thu Jun  3 09:34:04 2021

@author: Administrator
"""


import math 
import numpy as np
from scipy.sparse import find

def network_con_v2(IDX_from,IDX_to):

    if IDX_from.squeeze().ndim !=1:
        print('IDX_from should be a vector')
        
    if IDX_to.squeeze().ndim !=1:
        print('IDX_from should be a vector')
        
    #--seed point    
    seed_num=1
    subset_num=1
    search_num=1
    total_point=np.unique(np.concatenate((IDX_from,IDX_to),axis=0))
    total_num=total_point.shape[1]
    
    seed=IDX_from[1]
    flag_org=np.zeros((IDX_from.shape[0],1))
    flag=flag_org
    
    subset_tmp=[]
    seed_history=[]
    subset_before=[]
    subset={}
    point_num=[]
    
    while search_num<total_num:
            new=[]
            for i in range(seed):
				seed_history=np.concatenate((seed_history,seed[i]),axis=0)
				[tmp1_idx,_,_]=find(IDX_from==seed[i])
				new_to=IDX_to[tmp1_idx]
				[tmp2_idx,_,_]=find(IDX_to==seed[i])
				new_from=IDX_from[tmp2_idx]
				new_tmp=np.unique(np.concatenate((new_to,new_from),axis=0),axis=0)
				subset_tmp=np.concatenate((subset_tmp,seed,new_tmp),axis=0)
				subset_tmp=np.unique(subset_tmp,axis=0)
				new_tmp=np.setdiff1d(new_tmp,seed_history)         
				tmp_idx=np.unique(np.concatenate((tmp1_idx,tmp2_idx),axis=0),axis=0)
				flag[tmp_idx]=subset_num              
				new=np.concatenate((new,new_tmp),axis=0)                             
            for i in range(IDX_from.shape[0]) :
                if flag[i] !=0:
                    del IDX_from[i]        
            for i in range(IDX_to.shape[0]) :
                if flag[i] !=0:
                    del IDX_to[i]                           
            for i in range(flag.shape[0]) :
                if flag[i] !=0:
                    del flag[i]       
            new=np.unique(new,axis=0)         
            if new.shape[0]!=0:
					 new=np.setdiff1d(new,seed_history)
					 seed=new
            else:
                    if subset_num==1 :
							   subset[subset_num]=subset_tmp
							   point_num[subset_num]=subset_tmp.shape[0]
                    else :
                        for k in range(subset_num-1):
                            subset_before=np.concatenate((subset_before,subset[k]),axis=0) 
                        subset_tmpp=np.setdiff1d(subset_tmp,subset_before)
                        subset[subset_num]=subset_tmpp
                        point_num[subset_num]=subset_tmpp.shape[0]
                        del subset_tmpp
                    subset_num=subset_num+1
                    resi_point=np.setdiff1d(total_point,subset_tmp)
                    seed=resi_point[1]                 
            search_num=subset_tmp.shape[1]
            subset_before=[]
             
       
    if subset_num==1:
        print('The network is connected!')
        subset[subset_num]=total_point
        point_num[subset_num]=total_point.shape[0]       
    elif subset.shape[1] < subset_num :
         for p in range(subset_num-1):
                subset_before=np.concatenate((subset_before,subset[p]),axis=0) 
        subset_tmpp=np.setdiff1d(subset_tmp,subset_before)
        subset[subset_num]=subset_tmpp
        point_num[subset_num]=subset_tmpp.shape[0]
        del subset_tmpp
    
    tmp=abs(np.sort(-point_num))
    idx_sort=np.argsort(-point_num)
    subset_final=subset[idx_sort]
    point_num=tmp
    
    return subset_final,point_num
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
                       