import numpy as np
import pandas as pd
import scipy.sparse as sps
from scipy.sparse.csgraph import minimum_spanning_tree
from scipy.sparse import find
from scipy import stats
from shortbaseline_plot_new import shortbaseline_plot_new
from function_file import intersect_rows


def coregistration_ifg_select(baselinefile, plot_flag=0):
    """
    用来基线进行重合
    @param baselinefile: 基线文件名
    @param plot_flag: 是否画图，暂时未用到，填一个参数在此, 0为否， 1为是
    @return:
    """
    if baselinefile == "baseline":
        print("Read baseline file")
        data = pd.read_csv(baselinefile, header=None)
        SCE1, SCE2, Bp, Bt = [], [], [], []
        for i in range(len(data)):
            split_data = data[0][i].split("    ")
            SCE1.append(int(split_data[0].split("-")[0]))
            SCE2.append(int(split_data[0].split("-")[1]))
            Bp.append(float(data[0][i].split("    ")[2]))
            Bt.append(int(data[0][i].split("    ")[3]))
        SCE1 = np.array(SCE1).reshape(len(SCE1), 1)
        SCE2 = np.array(SCE2).reshape(len(SCE2), 1)
        Bp = np.array(Bp).reshape(len(Bp), 1)
        Bt = np.array(Bt).reshape(len(Bt), 1)
        baseline = np.hstack((SCE1, SCE2, Bp, Bt))
    elif baselinefile == "baseline_select":
        print("Read baseline_select file")
        data = pd.read_csv(baselinefile, header=None, delimiter="\t")
        SCE1 = np.array(data.iloc[:, 0]).reshape(data.shape[0], 1)
        SCE2 = np.array(data.iloc[:, 1]).reshape(data.shape[0], 1)
        Bp = np.array(data.iloc[:, 2]).reshape(data.shape[0], 1)
        Bt = np.array(data.iloc[:, 3]).reshape(data.shape[0], 1)
        baseline = np.hstack((SCE1, SCE2, Bp, Bt))
    else:
        raise Exception("baselinefile is wrong!")
    Bp_max = np.max(np.abs(Bp))
    Bt_max = np.max(np.abs(Bt))
    imp = np.hstack((SCE1, SCE2))
    slc = np.unique(np.vstack((SCE1, SCE2)))
    SLC = slc.reshape(-1, 1)
    NSLC = len(SLC)
    NIFG = baseline.shape[0]
    pair_index = np.zeros((NIFG, 2))
    for k in range(NSLC):
        kn = imp == SLC[k]
        pair_index[kn] = k
    re_rho = np.abs(Bp) / Bp_max + np.abs(Bt) / Bt_max
    SLC_SLC = sps.csr_matrix((re_rho.reshape(-1), (pair_index[:, 0], pair_index[:, 1])), shape=(NSLC, NSLC)).toarray()
    SLC_SLC_1 = SLC_SLC.conj().T
    UG = np.tril(SLC_SLC + SLC_SLC_1)
    ST = minimum_spanning_tree(UG)
    mst_x, mst_y, mst_z = find(ST)
    demst_xy = np.hstack((mst_x.reshape(-1, 1), mst_y.reshape(-1, 1)))
    demst_xy = np.sort(demst_xy, 1)
    ic = intersect_rows(pair_index, demst_xy)
    sb = baseline[ic, :].reshape(ic.shape[0], baseline.shape[-1])
    sb_re_rho = re_rho[ic].reshape(-1, 1)
    sb = sb[np.argsort(sb[:, 0])]
    if plot_flag == 1:
        shortbaseline_plot_new(sb, 1, 1, "coregistration_pairs_plot.eps")
    corege_sort_ix = 1
    master = stats.mode(np.hstack((sb[:, 0], sb[:, 1])).reshape(-1, 1))[0][0]
    iy, ix, _ = find(sb[:, 0:2] == master)
    invert_ix_m = ix[iy == 1]
    tmp1 = sb[invert_ix_m, 1]
    sb[invert_ix_m, 1] = sb[invert_ix_m, 0]
    sb[invert_ix_m, 0] = tmp1
    sb[invert_ix_m, 2] = -sb[invert_ix_m, 2]
    sb[invert_ix_m, 3] = -sb[invert_ix_m, 3]
    sb_tmp = np.hstack((sb, np.zeros((sb.shape[0], 1)).reshape(-1, 1), sb_re_rho))
    master_ix = ix
    de_master_ix = [i for i in range(len(sb))]
    for i in master_ix:
        if i in de_master_ix:
            de_master_ix.remove(i)
    sb = sb[de_master_ix, :]
    sb_tmp[master_ix, 4] = corege_sort_ix
    corege_sort_ix += 1
    master_2nd = sb_tmp[master_ix, 1]
    master_2nd_tmp = None
    while sb.any():
        for i in range(len(master_2nd)):
            ix_2nd_x, ix_2nd_y, _ = find(sb[:, 0:2] == master_2nd[i])
            xy = np.hstack((ix_2nd_x, ix_2nd_y))
            if i == 0:
                master_2nd_tmp = xy
            else:
                master_2nd_tmp = np.hstack((master_2nd_tmp, xy))
        master_2nd_tmp = master_2nd_tmp.reshape(-1, master_2nd.shape[0])
        tong_ix = intersect_rows(sb_tmp[:, 0:1], sb[master_2nd_tmp[:, 0], 0:1])
        sb_tmp[tong_ix, 4] = corege_sort_ix
        corege_sort_ix += 1
        _, nu_equal_2, _ = find(master_2nd_tmp[:, 1] == 1)
        invert_pairs = sb[master_2nd_tmp[nu_equal_2, 0], 0:2]
        invert_ix = intersect_rows(sb_tmp[:, 0:2], invert_pairs)
        if invert_ix.any():
            tmp = sb_tmp[invert_ix, 1]
            sb_tmp[invert_ix, 1] = sb_tmp[invert_ix, 0]
            sb_tmp[invert_ix, 0] = tmp
            sb_tmp[invert_ix, 2] = -sb_tmp[invert_ix, 2]
            sb_tmp[invert_ix, 3] = -sb_tmp[invert_ix, 3]
            invert_ix_m1 = master_2nd_tmp[nu_equal_2, 0]
            tmp2 = sb[invert_ix_m1, 1]
            sb[invert_ix_m1, 1] = sb[invert_ix_m1, 0]
            sb[invert_ix_m1, 0] = tmp2
            sb[invert_ix_m1, 2] = -sb[invert_ix_m1, 2]
            sb[invert_ix_m1, 3] = -sb[invert_ix_m1, 3]
            master_2nd = sb[master_2nd_tmp[:, 0], 1]
            master_ix = master_2nd_tmp[:, 0]
            de_master_ix = [i for i in range(len(sb))]
            for i in master_ix:
                if i in de_master_ix:
                    de_master_ix.remove(i)
            sb = sb[de_master_ix, :]
        else:
            sb = np.array([])
    sb = sb_tmp[np.argsort(sb_tmp[:, 0])]
    image_pairs = []
    for i, j in zip(sb[:, 0], sb[:, 1]):
        ele = str(int(i)) + "-" + str(int(j))
        image_pairs.append(ele)
    f = open("coreg_pairs", "w")
    for i in image_pairs:
        f.write(i + "\n")
    f.close()
    df = pd.DataFrame(sb)
    df[0], df[1], df[3] = df[0].astype(int), df[1].astype(int), df[3].astype(int)
    df.to_csv("coreg_shortbaseline", sep="\t", header=False, index=False)
    f = open("ref_image", "w")
    f.write(str(int(sb[0, 0])))
    f.close()
