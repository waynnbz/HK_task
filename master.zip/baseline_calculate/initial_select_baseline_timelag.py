import numpy as np
import pandas as pd
from function_file import intersect_rows
from initial_select_baseline3 import write_file
from shortbaseline_plot_new import shortbaseline_plot_new


def initial_select_baseline_timelag(bsname, time_lag=1, tri_flag=0, BpBt_ratio=1, plot_flag=0, nargout=0):
    """

    @param bsname:
    @param time_lag:
    @param tri_flag:
    @param BpBt_ratio:
    @param plot_flag: 是否画图
    @param nargout: 是否写入文件
    @return:
    """
    if not bsname:
        raise Exception("No input!")
    else:
        print("Read baseline file")
        data = pd.read_csv(bsname, header=None)
        SCE1, SCE2, Bp, Bt = [], [], [], []
        for i in range(len(data)):
            split_data = data[0][i].split("    ")
            SCE1.append(int(split_data[0].split("-")[0]))
            SCE2.append(int(split_data[0].split("-")[1]))
            Bp.append(float(data[0][i].split("    ")[2]))
            Bt.append(int(data[0][i].split("    ")[3]))
    SCE1 = np.array(SCE1).reshape(-1, 1)
    SCE2 = np.array(SCE2).reshape(-1, 1)
    Bp = np.array(Bp).reshape(-1, 1)
    Bt = np.array(Bt).reshape(-1, 1)
    SCE = np.sort(np.unique(np.hstack((SCE1, SCE2)))).reshape(-1, 1)
    imp = np.hstack((SCE1, SCE2))
    NSLC = len(SCE)
    NBL = len(SCE1)
    pair_index = np.zeros((NBL, 2))
    for k in range(NSLC):
        kn = imp == SCE[k]
        pair_index[kn] = k
    # max_Bp = np.max(np.abs(Bp))
    # max_Bt = np.max(np.abs(Bt))
    if int(tri_flag) == 0:
        N_image_pairs = NSLC * time_lag - time_lag * (time_lag + 1) / 2
        pair_index_select = np.zeros((int(N_image_pairs), 2))
        for i in range(1, time_lag + 1):
            start_idx = int(NSLC * (i - 1) - i * (i - 1) / 2 + 1)
            end_idx = int(NSLC * i - i * (i + 1) / 2)
            pair_index_select[start_idx - 1: end_idx, 0] = np.arange(1, NSLC + 1 - i)
            pair_index_select[start_idx - 1: end_idx, 1] = np.arange(1 + i, NSLC + 1)
        pair_index_select = pair_index_select[np.argsort(pair_index_select[:, 1])] - 1
    else:
        raise Exception("tri_flag != 0, function not implemented!")
    ia = intersect_rows(pair_index, pair_index_select)
    Bp_select = Bp[ia].reshape(ia.shape)
    Bt_select = Bt[ia].reshape(ia.shape)
    image_pairs = imp[ia, :].reshape(ia.shape[0], imp.shape[-1])
    baseline_select = np.hstack((image_pairs, Bp_select, Bt_select))
    shortbaseline = baseline_select
    print(shortbaseline)
    print('********* Final threshold used *********')
    print('maximum perpendicular baseline:      ' + str(float(np.max(np.abs(Bp_select)))) + ' (m)')
    print('maximum temporal baseline:           ' + str(int(np.max(np.abs(Bt_select)))) + ' (days)')
    print('********** Baseline Initial Selection **********')
    print('The Initial Number of Selected Baselines:        ' + str(len(ia)))
    print('The Number of SLC in total:                      ' + str(NSLC))
    print('******************************************')
    if int(nargout) == 0:
        write_file("images", SCE)
        df = pd.DataFrame(shortbaseline)
        df[0], df[1], df[3] = df[0].astype(int), df[1].astype(int), df[3].astype(int)
        df.to_csv("baseline_select", sep="\t", header=False, index=False)
        df.to_csv("shortbaseline", sep="\t", header=False, index=False)
        isp = []
        for i, j in zip(image_pairs[:, 0], image_pairs[:, 1]):
            ele = str(int(i)) + "-" + str(int(j))
            isp.append(ele)
        f = open("image_pairs", "w")
        for i in isp:
            f.write(i + "\n")
        f.close()
    if int(plot_flag) == 1:
        if int(time_lag) == 2:
            shortbaseline_plot_new(shortbaseline, date_flag=0, img_name="shortbaseline_plot.eps", time_flag=2)
        else:
            shortbaseline_plot_new(shortbaseline, date_flag=0, img_name="shortbaseline_plot.eps")
