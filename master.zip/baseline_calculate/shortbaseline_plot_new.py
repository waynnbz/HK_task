import numpy as np
import pandas as pd
from scipy.sparse import find
from function_file import intersect_rows
import matplotlib.pyplot as plt
from datetime import datetime
import matplotlib.dates as mdates


def spilt_date(num):
    num = str(num)
    y = int(num[:4])
    m = int(num[4:6])
    d = int(round(float(num[6:])))
    return str(y) + "-" + str(m) + "-" + str(d)


def shortbaseline_plot_new(shortbaseline, date_flag=0, master_flag=0, img_name="baseline", time_flag=0):
    data = pd.read_csv("baseline", header=None)
    SCE1, SCE2, Bp, Bt = [], [], [], []
    for i in range(len(data)):
        split_data = data[0][i].split("    ")
        SCE1.append(int(split_data[0].split("-")[0]))
        SCE2.append(int(split_data[0].split("-")[1]))
        Bp.append(float(data[0][i].split("    ")[2]))
    sce1 = np.array(SCE1).reshape(-1, 1)
    sce2 = np.array(SCE2).reshape(-1, 1)
    BP = np.array(Bp).reshape(-1, 1)
    sce = np.sort(np.unique(np.hstack((sce1, sce2))))
    SCE1 = shortbaseline[:, 0]
    SCE2 = shortbaseline[:, 1]
    SCE = np.sort(np.unique(np.hstack((SCE1, SCE2))))
    _, ix, _ = find(sce == SCE[0])
    NSLC = len(SCE)
    n = len(sce)
    ix = ix + 1
    Bp = BP[int(ix * n - n + 1 - (ix - 1) * ix / 2) - 1:int(ix * n - ix - (ix - 1) * ix / 2)]
    sce22 = sce2[int(ix * n - n + 1 - (ix - 1) * ix / 2) - 1:int(ix * n - ix - (ix - 1) * ix / 2)]
    ic = intersect_rows(SCE[1:], sce22)
    spa_coor = np.zeros((NSLC, 1))
    spa_coor[1:] = -1 * Bp[ic].reshape(ic.shape[0], 1)
    temp_coor = np.frompyfunc(spilt_date, 1, 1)(SCE)
    ymax = np.ceil(np.max(spa_coor)) + 100
    ymin = np.floor(np.min(spa_coor)) - 100
    plt.xlabel("Temporal Baseline (mm/yy)", fontweight='bold')
    plt.ylabel("Spatial Baseline (m)", fontweight='bold')
    plt.ylim([ymin, ymax])
    plt.grid()
    xs = [datetime.strptime(d, '%Y-%m-%d').date() for d in temp_coor]
    plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y/%m/%d'))
    plt.gca().xaxis.set_major_locator(mdates.MonthLocator())
    if int(time_flag) == 2:
        plt.plot(xs, spa_coor.reshape(-1), color='black', marker='o', markerfacecolor='green')
        plt.plot(xs[::2], spa_coor.reshape(-1)[::2], color='black', marker='o', markerfacecolor='green')
        plt.plot(xs[1::2], spa_coor.reshape(-1)[1::2], color='black', marker='o', markerfacecolor='green')
        if date_flag == 1:
            for i in range(len(xs)):
                plt.text(x=xs[i], y=spa_coor.reshape(-1)[i], s=temp_coor[i])
        plt.savefig(img_name)
        plt.show()
    else:
        if int(master_flag) == 1:
            spa_coor_1 = spa_coor[np.argsort(spa_coor[:, -1])].reshape(-1)
            temp_coor = temp_coor[np.argsort(spa_coor[:, -1])].reshape(-1)
            l1, l2 = [], []
            for i in range(len(spa_coor_1) - 1, -1, -1):
                l1.append(temp_coor[i])
                l2.append(spa_coor_1[i])
            xs = [datetime.strptime(d, '%Y-%m-%d').date() for d in l1]
            plt.plot(xs, l2, marker='o', color='black', markerfacecolor='green')
            if date_flag == 1:
                for i in range(len(xs)):
                    plt.text(x=xs[i], y=l2[i], s=l1[i])
            plt.savefig(img_name)
            plt.show()
        else:
            plt.plot(xs, spa_coor.reshape(-1), marker='o', color='black', markerfacecolor='green')
            if date_flag == 1:
                for i in range(len(xs)):
                    plt.text(x=xs[i], y=spa_coor.reshape(-1)[i], s=temp_coor[i])
            plt.savefig(img_name)
            plt.show()
