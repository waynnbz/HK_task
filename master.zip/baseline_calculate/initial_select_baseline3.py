import numpy as np
import pandas as pd
import scipy.sparse as sps


def write_file(filename, arr):
    f = open(filename, "w")
    for i in arr:
        f.write(str(int(i)) + "\n")
    f.close()


def initial_select_baseline3(bsname, max_Bp=0, max_Bt=0):
    """
    该函数用于初始选择斜坡网络没有的垂直基线和时间基线子集。
    根据基线文件中包含的基线值自动计算初始bp_threshold和bt_threshold。
    Input parameter:
    bsname         : baseline file name
    max_Bp         : maximum perpendicular baseline
    max_Bt         : maximum temporal baseline
    """
    if not bsname:
        raise Exception("No input!")
    else:
        print("Read baseline file")
        data = pd.read_csv(bsname, header=None)
        SCE1, SCE2, Bp, Bt = [], [], [], []
        for i in range(len(data)):
            split_data = data[0][i].split("    ")
            SCE1.append(int(split_data[0].split("-")[0]))
            SCE2.append(int(split_data[0].split("-")[1]))
            Bp.append(float(data[0][i].split("    ")[2]))
            Bt.append(int(data[0][i].split("    ")[3]))
    sce = np.array([SCE1, SCE2])
    SCE1_1 = np.array([SCE1]).reshape(len(data), 1)
    SCE2_1 = np.array([SCE2]).reshape(len(data), 1)
    NBL = len(SCE1)
    SCE = sorted(np.unique(sce))
    SCE1.extend(SCE2)
    imp = np.hstack((SCE1_1, SCE2_1))
    NSLC = len(SCE)
    pair_index = np.zeros((NBL, 2))
    for k in range(NSLC):
        kn = (imp == SCE[k])
        pair_index[kn] = k
    abs_Bp = np.abs(Bp)
    abs_Bt = np.abs(Bt)
    uni_Bp = sorted(np.unique(np.ceil(abs_Bp / 10) * 10))
    uni_Bt = sorted(np.unique(abs_Bt))
    max_Bp = min(max_Bp, np.max(uni_Bp))
    max_Bt = min(max_Bt, np.max(uni_Bt))
    uni_Bp = np.array([uni_Bp])
    uni_Bt = np.array([uni_Bt])
    uni_Bp = uni_Bp[uni_Bp >= max_Bp]
    uni_Bt = uni_Bt[uni_Bt >= max_Bt]
    uni_Bp = uni_Bp.reshape(len(uni_Bp), 1)
    uni_Bt = uni_Bt.reshape(len(uni_Bt), 1)
    Bp_threshold = np.zeros((len(uni_Bp), len(uni_Bt)))
    Bt_threshold = np.zeros((len(uni_Bp), len(uni_Bt)))
    ifg_count = NBL * np.ones((len(uni_Bp), len(uni_Bt)))
    for i in range(len(uni_Bp)):
        for j in range(len(uni_Bt)):
            Bp_index, Bt_index = (abs_Bp <= uni_Bp[i][0]), (abs_Bt <= uni_Bt[j][0])
            Bp_Bt_index = (Bp_index & Bt_index)
            select_pair_index = pair_index[Bp_Bt_index, :]
            NIFG = 0
            if select_pair_index.any():
                NIFG = select_pair_index.shape[0]
            arr1, arr2 = np.ones((NIFG, 1)), np.ones((NIFG, 1)) * -1
            arr3 = np.vstack((arr1, arr2))
            IFG_SLC = sps.csr_matrix((arr3.reshape(-1), (np.tile(np.arange(NIFG), (2, 1)).reshape(-1),
                                                         np.ravel(select_pair_index, 'F'))), shape=(NIFG, NSLC))
            pair_rank = 0
            if IFG_SLC.toarray().any():
                pair_rank = np.linalg.matrix_rank(IFG_SLC.toarray())
            if pair_rank == NSLC - 1:
                Bp_threshold[i, j] = uni_Bp[i]
                Bt_threshold[i, j] = uni_Bt[j]
                ifg_count[i, j] = np.sum(Bp_Bt_index)
    x = np.ravel(ifg_count, 'F')
    x = x.reshape(len(x), 1)
    y = np.ravel(Bp_threshold, 'F')
    y = y.reshape(len(y), 1)
    z = np.ravel(Bt_threshold, 'F')
    z = z.reshape(len(z), 1)
    ifgBpt_matrix = np.hstack((x, y, z))
    ifgBpt_matrix_norm = np.hstack((x / NBL, y / np.max(np.abs(Bp)), z / np.max(np.abs(Bt))))
    ifgBpt_index = np.sum(np.square(ifgBpt_matrix_norm), axis=1).reshape(len(ifgBpt_matrix_norm), 1)
    ifgBpt_matrix = np.hstack((ifgBpt_matrix, ifgBpt_index))
    index_sort = np.argsort(ifgBpt_matrix[:, 3])
    ifgBpt_matrix = ifgBpt_matrix[index_sort, :]
    NIFG = int(ifgBpt_matrix[0, 0])
    Bp_threshold_final = ifgBpt_matrix[0, 1]
    Bt_threshold_final = ifgBpt_matrix[0, 2]
    Bp_index = abs_Bp <= Bp_threshold_final
    Bt_index = abs_Bt <= Bt_threshold_final
    Bp_Bt_index = Bp_index & Bt_index
    print("********* Final threshold used *********")
    print("perpendicular baseline:      %d (m)" % int(Bp_threshold_final))
    print("temporal baseline:           %d (day)" % int(Bt_threshold_final))
    print("********** Baseline Initial Selection **********")
    print("The Initial Number of Selected Baselines:     " + str(NIFG))
    print("The Number of SLC in total:                   " + str(NSLC))
    print("******************************************")
    imp_final = imp[Bp_Bt_index, :]
    SCE_final = np.sort(np.unique(np.ravel(imp_final, 'F')))
    SCE_final = SCE_final.reshape(len(SCE_final), 1)
    SCE_not_used = np.setdiff1d(SCE, SCE_final)
    Bp = np.array(Bp).reshape(len(Bp), 1)
    Bt = np.array(Bt).reshape(len(Bt), 1)
    baseline_select = np.hstack((SCE1_1[Bp_Bt_index], SCE2_1[Bp_Bt_index], Bp[Bp_Bt_index], Bt[Bp_Bt_index]))
    write_file('images_ori', SCE)
    write_file("images", SCE_final)
    write_file("images_not_used", SCE_not_used)
    df = pd.DataFrame(baseline_select)
    df[0], df[1], df[3] = df[0].astype(int), df[1].astype(int), df[3].astype(int)
    df.to_csv("baseline_select", sep="\t", header=False, index=False)
    image_pairs = []
    for i, j in zip(df[0], df[1]):
        ele = str(i) + "-" + str(j)
        image_pairs.append(ele)
    f = open("image_pairs", "w")
    for i in image_pairs:
        f.write(i + "\n")
    f.close()
