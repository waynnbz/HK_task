import numpy as np


def intersect_rows(arr1, arr2):
    l = []
    for i in range(len(arr1)):
        for j in range(len(arr2)):
            flag = arr1[i] == arr2[j]
            if len(np.unique(flag)) == 1 and np.unique(flag)[0] == True:
                l.append(i)
    return np.array(list(set(l))).reshape(-1, 1)